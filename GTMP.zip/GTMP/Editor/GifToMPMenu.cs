﻿using System;
using System.IO;
using System.Net;
using UnityEditor;
using UnityEngine;

// Put this script in an "Editor" folder (e.g. Assets/Editor/GifToMPMenu.cs)
// so Unity knows it belongs in the Editor rather than in the runtime build.

public static class GifToMPMenu
{
    // Key used for storing the "react to UltEvents" setting in EditorPrefs.
    private const string ReactToUltEventsKey = "GifToMP_ReactsToUltEvents";

    // Define the current version of GifToMP.
    // When you release a new version, update this string (e.g. "1.0.1", "1.1.0", etc.).
    private const string CurrentVersion = "1.0.0";

    // GitHub API URL for the latest release of gif-to-mp.
    private const string LatestReleaseApiUrl = "https://api.github.com/repos/the-bl-heretic/gif-to-mp/releases/latest";

    // 1) Create a top‐level "GifToMP" menu with a "Settings" item underneath.
    // When clicked, this will open the Settings window.
    [MenuItem("GifToMP/Settings")]
    private static void OpenSettingsWindow()
    {
        // Get or create the settings window
        GifToMPSettingsWindow.ShowWindow();
    }

    // 2) Under the same top‐level menu, add a "Check For Updates" entry.
    // Clicking it will now attempt to contact GitHub and compare versions.
    [MenuItem("GifToMP/Check For Updates")]
    private static void CheckForUpdates()
    {
        try
        {
            // 1. Create a request to the GitHub Releases API for the latest release.
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(LatestReleaseApiUrl);
            request.UserAgent = "GifToMP-UnityEditor"; // GitHub requires a User-Agent header

            using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
            using (StreamReader reader = new StreamReader(response.GetResponseStream()))
            {
                string json = reader.ReadToEnd();
                // 2. Parse the JSON for "tag_name"
                ReleaseInfo info = JsonUtility.FromJson<ReleaseInfo>(json);
                if (string.IsNullOrEmpty(info.tag_name))
                {
                    EditorUtility.DisplayDialog(
                        "GifToMP – Check For Updates",
                        "Could not parse version information from GitHub response.",
                        "OK"
                    );
                    return;
                }

                // 3. Clean up tag_name (remove leading 'v' if present)
                string latestVersion = info.tag_name.StartsWith("v", StringComparison.OrdinalIgnoreCase)
                    ? info.tag_name.Substring(1)
                    : info.tag_name;

                // 4. Compare semantic versions
                int comparison = CompareVersions(latestVersion, CurrentVersion);
                if (comparison > 0)
                {
                    // A newer version exists
                    bool openRepo = EditorUtility.DisplayDialog(
                        "GifToMP – Update Available",
                        $"A new version of GifToMP is available:\n\n" +
                        $"Latest: {latestVersion}\n" +
                        $"Installed: {CurrentVersion}\n\n" +
                        $"Press \"Open GitHub\" to view the release page and download the update.",
                        "Open GitHub",
                        "Later"
                    );
                    if (openRepo)
                    {
                        UnityEngine.Application.OpenURL("https://github.com/the-bl-heretic/gif-to-mp/releases/latest");
                    }
                }
                else if (comparison < 0)
                {
                    // Local version is somehow newer than GitHub (unlikely, but handle gracefully)
                    EditorUtility.DisplayDialog(
                        "GifToMP – Version Check",
                        $"You are running a newer version ({CurrentVersion}) than GitHub’s latest release ({latestVersion}).",
                        "OK"
                    );
                }
                else
                {
                    // Versions match
                    EditorUtility.DisplayDialog(
                        "GifToMP – Up To Date",
                        $"You are already using the latest version of GifToMP ({CurrentVersion}).",
                        "OK"
                    );
                }
            }
        }
        catch (WebException webEx)
        {
            string message = webEx.Message;
            if (webEx.Response is HttpWebResponse httpResponse)
            {
                message = $"HTTP {(int)httpResponse.StatusCode} – {httpResponse.StatusDescription}";
            }
            EditorUtility.DisplayDialog(
                "GifToMP – Check For Updates Failed",
                $"Could not check for updates:\n\n{message}\n\n" +
                $"Please check your internet connection or try again later.",
                "OK"
            );
        }
        catch (Exception ex)
        {
            EditorUtility.DisplayDialog(
                "GifToMP – Check For Updates Error",
                $"An unexpected error occurred while checking for updates:\n\n{ex.Message}",
                "OK"
            );
        }
    }

    // 3) We also want to show a checkmark next to "Settings" if it's currently enabled.
    //    (Unity allows us to use a validation function and set a “checked” state.)
    [MenuItem("GifToMP/Settings", validate = true)]
    private static bool ToggleSettingsValidate()
    {
        bool reacts = EditorPrefs.GetBool(ReactToUltEventsKey, false);
        Menu.SetChecked("GifToMP/Settings", reacts);
        return true;
    }

    /// <summary>
    /// Simple semantic version comparison.
    /// Returns:
    ///   > 0 if versionA &gt; versionB
    ///   = 0 if equal
    ///   &lt; 0 if versionA &lt; versionB
    /// Splits on '.', compares each numeric part in order.
    /// </summary>
    private static int CompareVersions(string versionA, string versionB)
    {
        string[] partsA = versionA.Split('.');
        string[] partsB = versionB.Split('.');
        int length = Math.Max(partsA.Length, partsB.Length);

        for (int i = 0; i < length; i++)
        {
            int a = (i < partsA.Length && int.TryParse(partsA[i], out int va)) ? va : 0;
            int b = (i < partsB.Length && int.TryParse(partsB[i], out int vb)) ? vb : 0;
            if (a != b)
                return a.CompareTo(b);
        }
        return 0;
    }

    // Data class for parsing the "tag_name" field from GitHub's JSON
    [Serializable]
    private class ReleaseInfo
    {
        public string tag_name;
    }
}


// This class defines a small EditorWindow that appears when you choose GifToMP → Settings.
// It allows the user to toggle a single checkbox: "React to UltEvents".

public class GifToMPSettingsWindow : EditorWindow
{
    // We store the same key in EditorPrefs so that the setting persists between sessions.
    private const string ReactToUltEventsKey = "GifToMP_ReactsToUltEvents";
    private bool _reactsToUltEvents;

    // Margin and spacing constants
    private const float kPadding = 8f;
    private const float kLineHeight = 18f;

    public static void ShowWindow()
    {
        // Try to find an existing instance
        GifToMPSettingsWindow window = GetWindow<GifToMPSettingsWindow>(false, "GifToMP Settings", true);
        window.minSize = new Vector2(300, 80);
        window.LoadPrefs();
        window.Show();
    }

    private void OnEnable()
    {
        // When the window is enabled (opened or recompiled), load the stored preference
        LoadPrefs();
    }

    private void LoadPrefs()
    {
        // Default value is false if the key doesn’t exist
        _reactsToUltEvents = EditorPrefs.GetBool(ReactToUltEventsKey, false);
    }

    private void SavePrefs()
    {
        EditorPrefs.SetBool(ReactToUltEventsKey, _reactsToUltEvents);
    }

    private void OnGUI()
    {
        GUILayout.Space(kPadding);

        EditorGUILayout.LabelField(
            "GifToMP General Settings",
            EditorStyles.boldLabel
        );

        GUILayout.Space(kPadding);

        EditorGUI.BeginChangeCheck();
        _reactsToUltEvents = EditorGUILayout.ToggleLeft(
            new GUIContent(
                "React to UltEvents",
                "If enabled, GifToMP will automatically respond to UltEvents in your scene."
            ),
            _reactsToUltEvents
        );
        if (EditorGUI.EndChangeCheck())
        {
            SavePrefs();
            // Since this setting changes the behavior of your runtime scripts,
            // you might want to force a recompilation or re‐load of runtime components.
            // For now, we simply save to EditorPrefs.
        }

        GUILayout.FlexibleSpace();

        // Optionally, add a “Help” box or a link in the future
        EditorGUILayout.HelpBox(
            "“React to UltEvents” determines whether the runtime GifPlayerTrigger\n" +
            "listens for UltEvent calls automatically. If disabled, you must call\n" +
            "PlayGif() manually from your own scripts or inspector buttons.\n" +
            "Or check 'Play On Awake' to play the GIF automatically.",
            MessageType.Info
        );
    }
}
